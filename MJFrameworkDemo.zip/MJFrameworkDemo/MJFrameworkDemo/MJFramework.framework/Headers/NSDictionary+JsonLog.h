//
//  NSDictionary+JsonLog.h [控制台输出中文格式]
//  QQ群:286380794
//
//  Created by 郭明健 on 2015/9/8.
//  Copyright © 2016年 MJ Guo. All rights reserved.
//
//  https://github.com/GuoMingJian/MJFramework
//

#import <Foundation/Foundation.h>

@interface NSDictionary (JsonLog)

@end
