//
//  MJNavigationController.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2016/12/30.
//  Copyright © 2016年 MJ Guo. All rights reserved.
//

#import "MJNavigationController.h"

@interface MJNavigationController ()

@end

@implementation MJNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置导航栏默认颜色
    [self.navigationBar setBarTintColor:MainDefaultColor];
}

//重写
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [super pushViewController:viewController animated:YES];
    
    //返回按钮
    if (self.childViewControllers.count > 1)
    {
        UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        backBtn.frame=CGRectMake(0, 0, 15, 23);
        [backBtn setBackgroundImage:[UIImage imageNamed:@"navigation_back"] forState:0];
        [backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    }
}

-(void)backAction
{
    [self popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
