//
//  TabBarController.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2016/12/30.
//  Copyright © 2016年 MJ Guo. All rights reserved.
//

#import "TabBarController.h"

#import "MJNavigationController.h"

#import "MainMenuViewController.h"
#import "NewsViewController.h"
#import "FoundViewController.h"
#import "MySourceViewController.h"

@interface TabBarController ()<MJTabBarViewDelegate>

@end

@implementation TabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initViewControllers];
    
    [self initMJTabBarView];
}

- (void)initViewControllers
{
    NSMutableArray *vcArrayM = [NSMutableArray array];
    
    //
    MainMenuViewController *mainMenuVC = [[MainMenuViewController alloc] init];
    MJNavigationController *mainNavVC = [[MJNavigationController alloc] initWithRootViewController:mainMenuVC];
    [vcArrayM addObject:mainNavVC];
    
    NewsViewController *newsViewVC = [[NewsViewController alloc] init];
    MJNavigationController *newsNavVC = [[MJNavigationController alloc] initWithRootViewController:newsViewVC];
    [vcArrayM addObject:newsNavVC];
    
    FoundViewController *foundVC = [[FoundViewController alloc] init];
    MJNavigationController *foundNavVC = [[MJNavigationController alloc] initWithRootViewController:foundVC];
    [vcArrayM addObject:foundNavVC];
    
    MySourceViewController *mySourceVC = [[MySourceViewController alloc] init];
    MJNavigationController *mySourceNavVC = [[MJNavigationController alloc] initWithRootViewController:mySourceVC];
    [vcArrayM addObject:mySourceNavVC];
    
    //
    self.viewControllers = vcArrayM;
}

- (void)initMJTabBarView
{
    MJTabBarView *mjTabBar = [[MJTabBarView alloc] initWithFrame:self.tabBar.bounds];
    mjTabBar.delegate = self;
    CGSize iconSize = CGSizeMake(23, 23);
    NSArray *normalArray = @[[UIImage imageNamed:@"A.png"],
                             [UIImage imageNamed:@"B.png"],
                             [UIImage imageNamed:@"C.png"],
                             [UIImage imageNamed:@"D.png"]];
    NSArray *selectArray = @[[UIImage imageNamed:@"A_a.png"],
                             [UIImage imageNamed:@"B_b.png"],
                             [UIImage imageNamed:@"C_c.png"],
                             [UIImage imageNamed:@"D_d.png"]];
    [mjTabBar setMJTabBarNormalIcons:normalArray selectedIcons:selectArray iconSize:iconSize];
    [mjTabBar setBackgroundColor:kRGBColor(50, 55, 58)];
    NSArray *titleArray = @[@"主菜单", @"消息", @"发现", @"我的资料"];
    [mjTabBar setMJTabBarTexts:titleArray normalTextColor:[UIColor darkGrayColor] selectedTextColor:MainDefaultColor];
    [mjTabBar showMJTabBarInTabBarController:self];
}

#pragma mark - MJTabBarDelegate

- (void)tabBar:(MJTabBarView *)tabBar
  selectedFrom:(NSInteger)from
            to:(NSInteger)to
{
    self.selectedIndex = to;
}

#pragma mark -

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
