//
//  MainMenuViewController.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2016/12/30.
//  Copyright © 2016年 MJ Guo. All rights reserved.
//

#import "MainMenuViewController.h"

#import "MJTabBarViewDemoVC.h"
#import "MJUtilitiesDemoVC.h"
#import "MJActivityViewDemoVC.h"
#import "MJLoopScrollViewDemoVC.h"
#import "MJImageClipViewDemoVC.h"
#import "MJPopViewDemoVC.h"
#import "MJCollectionViewFlowLayoutDemoVC.h"

@interface MainMenuViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *loopSrollBGView;
@property (weak, nonatomic) IBOutlet UITableView *itemsTableView;

@end

@implementation MainMenuViewController
{
    NSMutableArray *dataArray;
    
    MJLoopScrollView *mjLoopScrollView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //
    self.navigationItem.titleView = setNavigationBarTitleView(@"主菜单");
    
    //监听横竖屏切换
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientChange) name:UIDeviceOrientationDidChangeNotification object:nil];
    
    //1.首先展示轮播图[MJLoopScrollView.h]
    [self initLoopScrollView];
    
    //2.展示MJFramework 类文件使用方法跟效果
    dataArray = [NSMutableArray array];
    [dataArray addObject:@"MJTabBarView.h"];
    [dataArray addObject:@"MJUtilities.h"];
    [dataArray addObject:@"MJActivityView.h"];
    [dataArray addObject:@"MJLoopScrollView.h"];
    [dataArray addObject:@"MJImageClipView.h"];
    [dataArray addObject:@"UIView+PopView.h"];
    [dataArray addObject:@"MJCollectionViewFlowLayout.h"];
    
    self.itemsTableView.dataSource = self;
    self.itemsTableView.delegate = self;
    self.itemsTableView.showsVerticalScrollIndicator = NO;
    self.itemsTableView.tableFooterView = [[UIView alloc] init];
    [self.itemsTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    
    //3.MJDBHelper 使用
    [self MJDataBaseUse];
    
}

- (void)initLoopScrollView
{
    mjLoopScrollView = [[MJLoopScrollView alloc] init];
    mjLoopScrollView.frame = self.loopSrollBGView.bounds;
    [self.loopSrollBGView addSubview:mjLoopScrollView];
    
    //图片数组
    NSMutableArray *imageM = [NSMutableArray array];

    [imageM addObject:@"http://sports.espn.go.com/photo/2008/0423/nba_ap_kbryant1_412.jpg"];
    [imageM addObject:@"http://upload.taihainet.com/2016/1111/1478797486684.jpeg"];
    [imageM addObject:@"http://d.hiphotos.baidu.com/zhidao/pic/item/cb8065380cd7912314b44633ad345982b2b78025.jpg"];
    [imageM addObject:@"http://d.hiphotos.baidu.com/zhidao/pic/item/4e4a20a4462309f76307dba4740e0cf3d7cad618.jpg"];
    [imageM addObject:@"http://www.cnidea.net/zhibo/u/20160414/16104807373250436817.jpg"];
    
    [mjLoopScrollView startAutoRunningImages:imageM clickAction:^(UIImageView *imageView, int index) {
        NSString *msg = [NSString stringWithFormat:@"您点击的是:图片%d", index];
        [MJUtilities showMJTipView:msg];
    }];
}

- (void)MJDataBaseUse
{
    [MJDBHelper setCurrentDataBase:@"YST"];
    [MJDBHelper createDataBase:@"YST"];
    NSString *tbName = @"User";
    BOOL bl = [MJDBHelper isExistsTable:tbName];
    NSMutableDictionary *dicM = [NSMutableDictionary dictionary];
    dicM[@"idCard"] = @"440223199109194444";
    dicM[@"name"] = @"郭明健";
    dicM[@"age"] = @"26";
    dicM[@"sex"] = @"男";
    dicM[@"time"] = [MJUtilities dateStringByDate:[NSDate date] formater:nil];
    if (bl)
    {
        //增
        //[MJDBHelper insertInToTable:tbName dictionary:dicM isOnlyOne:YES];
        //[MJDBHelper insertInToTable:tbName dictionary:dicM isOnlyOne:NO];
    }
    else
    {
        //创建
        //[MJDBHelper createTable:tbName dictionary:dicM primaryKey:@"idCard"];
        [MJDBHelper createTable:tbName dictionary:dicM primaryKey:nil];
    }
    
    //删
    NSString *time = @"____";
    NSString *sql = [NSString stringWithFormat:@"delete from %@ where %@ = '%@'", tbName, @"time", time];
    [MJDBHelper deleteFromTable:tbName sql:sql];
    
    //改
    time = [MJUtilities dateStringByDate:[NSDate date] formater:nil];
    sql = [NSString stringWithFormat:@"update %@ set %@ = '%@' where %@ = '%@'", tbName, @"time", @"____", @"time", time];
    //[MJDBHelper updateFromTable:tbName sql:sql];
    
    //查
    sql = [NSString stringWithFormat:@"select * from %@", tbName];
    //sql = [NSString stringWithFormat:@"select * from %@ where %@ = '%@'", tbName, @"time", @"2017-01-16 14:04:47"];
    NSArray *array = [MJDBHelper selectFromTable:tbName sql:sql];
    NSLog(@"查询结果:%@", array);
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    if (indexPath.row < dataArray.count)
    {//保证不越界
        cell.textLabel.text = dataArray[indexPath.row];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右箭头
    }
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"MJFramework库文件演示列表:";
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row < dataArray.count)
    {//保证不越界
        NSString *clickStr = dataArray[indexPath.row];
        
        if ([clickStr isEqualToString:@"MJTabBarView.h"])
        {
            MJTabBarViewDemoVC *mjTabBarDemoVC = [[MJTabBarViewDemoVC alloc] init];
            [self.navigationController pushViewController:mjTabBarDemoVC animated:YES];
        }
        else if ([clickStr isEqualToString:@"MJUtilities.h"])
        {
            MJUtilitiesDemoVC *mjUtilitiesDemoVC = [[MJUtilitiesDemoVC alloc] init];
            [self.navigationController pushViewController:mjUtilitiesDemoVC animated:YES];
        }
        else if ([clickStr isEqualToString:@"MJActivityView.h"])
        {
            MJActivityViewDemoVC *mjActivityViewDemoVC = [[MJActivityViewDemoVC alloc] init];
            [self.navigationController pushViewController:mjActivityViewDemoVC animated:YES];
        }
        else if ([clickStr isEqualToString:@"MJLoopScrollView.h"])
        {
            MJLoopScrollViewDemoVC *mjLoopScrollViewDemoVC = [[MJLoopScrollViewDemoVC alloc] init];
            [self.navigationController pushViewController:mjLoopScrollViewDemoVC animated:YES];
        }
        else if ([clickStr isEqualToString:@"MJImageClipView.h"])
        {
            MJImageClipViewDemoVC *mjImageClipViewDemoVC = [[MJImageClipViewDemoVC alloc] init];
            [self.navigationController pushViewController:mjImageClipViewDemoVC animated:YES];
        }
        else if ([clickStr isEqualToString:@"UIView+PopView.h"])
        {
            MJPopViewDemoVC *mjPopViewDemoVC = [[MJPopViewDemoVC alloc] init];
            [self.navigationController pushViewController:mjPopViewDemoVC animated:YES];
        }
        else if ([clickStr isEqualToString:@"MJCollectionViewFlowLayout.h"])
        {
            MJCollectionViewFlowLayoutDemoVC *cflVC = [[MJCollectionViewFlowLayoutDemoVC alloc] init];
            [self.navigationController pushViewController:cflVC animated:YES];
        }
    }
}

#pragma mark -

//屏幕旋转
- (void)orientChange
{
    CGRect rect = self.loopSrollBGView.bounds;
    [mjLoopScrollView orientChangeUpdateFrame:rect];
}

#pragma mark -

//- (void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    
//    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
//}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
