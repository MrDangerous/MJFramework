//
//  MainMenuViewController.h
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2016/12/30.
//  Copyright © 2016年 MJ Guo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainMenuViewController : UIViewController

@end
