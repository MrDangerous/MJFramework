//
//  MJTabBarViewDemoVC.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2016/12/30.
//  Copyright © 2016年 MJ Guo. All rights reserved.
//

#import "MJTabBarViewDemoVC.h"

@interface MJTabBarViewDemoVC ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *unReadMsgTextField;
@property (weak, nonatomic) IBOutlet UITextField *mjTabBarIndexTextField;

@end

@implementation MJTabBarViewDemoVC
{
    MJTabBarView *mjTabBar;
    
    UITextField *currentTextField;//记录当前操作的TextField
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = setNavigationBarTitleView(@"MJTabBarView用法演示");
    
    mjTabBar = [MJTabBarView getMJTabBar:self.tabBarController];
    
    //添加点击屏幕缩回键盘
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backKeyBoard)];
    [self.view addGestureRecognizer:tap];
}

//- (void)viewWillAppear:(BOOL)animated
//{
//    [super viewWillAppear:animated];
//    
//    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
//}
//
//- (void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    
//    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - actions

//显示MJTabBar
- (IBAction)showMJTabBar:(id)sender
{
    [mjTabBar showMJTabBar];
}

//隐藏MJTabBar
- (IBAction)hiddenMJTabBar:(id)sender
{
    [mjTabBar hiddenMJTabBar];
}

//显示小圆点
- (IBAction)showSmallRedView:(id)sender
{
    [mjTabBar setDefaultSamllRedViewBGColor:kRandomColor];
    
    [mjTabBar showMJTabBarSamllRedView:0];
    [mjTabBar showMJTabBarSamllRedView:1];
    [mjTabBar showMJTabBarSamllRedView:2];
    [mjTabBar showMJTabBarSamllRedView:3];
}

//隐藏小圆点
- (IBAction)hiddenSmallRedView:(id)sender
{
    [mjTabBar hiddenMJTabBarSamllRedView:0];
    [mjTabBar hiddenMJTabBarSamllRedView:1];
    [mjTabBar hiddenMJTabBarSamllRedView:2];
    [mjTabBar hiddenMJTabBarSamllRedView:3];
}

//显示未读信息
- (IBAction)showUnReadMessage:(id)sender
{
    //未读信息数量
    NSInteger unReadMsgNumber = [self.unReadMsgTextField.text integerValue];//默认用户输入正确，未做异常处理。
    //未读信息索引
    NSInteger unReadMsgIndex = [self.mjTabBarIndexTextField.text integerValue];
    
    [mjTabBar showMJTaBarUnReadMessage:unReadMsgIndex messageCount:unReadMsgNumber];
}

//隐藏未读信息
- (IBAction)hiddenUnReadMessage:(id)sender
{
    //未读信息索引
    NSInteger unReadMsgIndex = [self.mjTabBarIndexTextField.text integerValue];//默认用户输入正确，未做异常处理。
    
    [mjTabBar hiddenMJTaBarUnReadMessage:unReadMsgIndex];
}

//触发对应索引的菜单
- (IBAction)clickMJTabBarIndex:(id)sender
{
    //索引
    NSInteger unReadMsgIndex = [self.mjTabBarIndexTextField.text integerValue];//默认用户输入正确，未做异常处理。
    
    [mjTabBar clickMJTabBarButtonByIndex:unReadMsgIndex];
}

//显示对应索引未读信息数量
- (IBAction)showIndexUnReadMsgNumber:(id)sender
{
    NSInteger unReadMsgIndex = [self.mjTabBarIndexTextField.text integerValue];//默认用户输入正确，未做异常处理。
    NSString *unReadMsgNumber = [mjTabBar getUnReadMsgByIndex:unReadMsgIndex isSmallRedData:NO];
    [MJUtilities showMJTipView:[NSString stringWithFormat:@"%@条未读消息", unReadMsgNumber]];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentTextField = textField;
}

#pragma mark -

- (void)backKeyBoard
{
    [currentTextField resignFirstResponder];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
