//
//  MJImageClipViewDemoVC.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/5.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "MJImageClipViewDemoVC.h"

@interface MJImageClipViewDemoVC ()<UIImagePickerControllerDelegate , UINavigationControllerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UITextField *circleWidthTextField;

@end

@implementation MJImageClipViewDemoVC
{
    UITextField *currentTextField;//记录当前操作的TextField
    
    CGFloat _clipCircleWidth;
    ImageClipType _clipType;
    
    UIImage *saveImage;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = setNavigationBarTitleView(@"MJImageClipView用法演示");
    
    //添加点击屏幕缩回键盘
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backKeyBoard)];
    [self.view addGestureRecognizer:tap];
    
    //
    self.headImageView.image = [UIImage imageNamed:@"defaultHeadImage"];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    [MJUtilities setCornerRadius:self.headImageView cornerRadiusValue:self.headImageView.frame.size.width / 2.0];
    self.headImageView.layer.borderWidth = 1.5f;
    self.headImageView.layer.borderColor = [UIColor whiteColor].CGColor;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - actions

//点击头像
- (IBAction)clickHeadImageView:(id)sender
{
    [self chooseGetImageType];
}

//切圆形
- (IBAction)clipCircle:(id)sender
{
    _clipType = ImageClipCircle;
    [MJUtilities showMJTipView:@"切圆形"];
}

//切横图
- (IBAction)clipWidth:(id)sender
{
    _clipType = ImageClipHerizonRect;
    [MJUtilities showMJTipView:@"切横图"];
}

//切竖图
- (IBAction)clipHeight:(id)sender
{
    _clipType = ImageClipVerticalRect;
    [MJUtilities showMJTipView:@"切竖图"];
}

//换张图片
- (IBAction)changeImage:(id)sender
{
    saveImage = [UIImage imageNamed:@"backgroundImage"];
    [MJUtilities showMJTipView:@"换张图片"];
}

#pragma mark -

- (void)chooseGetImageType
{
    UIAlertAction *photoLibrary = [UIAlertAction actionWithTitle:@"相册" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UIImagePickerController *pickerVC = [[UIImagePickerController alloc] init];
        [pickerVC setAllowsEditing:NO];
        [pickerVC setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
        [pickerVC setDelegate:self];
        [self presentViewController:pickerVC animated:YES completion:nil];
        [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
    }];
    UIAlertAction *camera = [UIAlertAction actionWithTitle:@"相机" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
        {
            UIImagePickerController *pickerVC = [[UIImagePickerController alloc] init];
            [pickerVC setAllowsEditing:NO];
            [pickerVC setSourceType:UIImagePickerControllerSourceTypeCamera];
            [pickerVC setDelegate:self];
            [self presentViewController:pickerVC animated:YES completion:nil];
            [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
        }
        else
        {
            //NSLog(@"该设备无摄像头");
            [MJUtilities showMJTipView:@"该设备无摄像头"];
        }
    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    //
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [alertC addAction:photoLibrary];
    [alertC addAction:camera];
    [alertC addAction:cancel];
    [self presentViewController:alertC animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    UIImage *image = info[@"UIImagePickerControllerOriginalImage"];
    [self dismissViewControllerAnimated:YES completion:nil];
    
    //处理图片剪切
    MJImageClipView *mjClipView = [[MJImageClipView alloc] initWithFrame:self.view.bounds];
    [self.navigationController.view addSubview:mjClipView];
    
    mjClipView.clipType = _clipType;
    mjClipView.circleWidth = _clipCircleWidth;
    
    //
    [mjClipView clipImage:image callBack:^(UIImage *image)
     {
         if (image)
         {
             self.headImageView.image = image;
         }
         [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
     }];
    
    //
    if (saveImage)
    {
        mjClipView.needClipImage = saveImage;
        saveImage = nil;
    }
}

#pragma mark -

- (void)backKeyBoard
{
    [currentTextField resignFirstResponder];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentTextField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == self.circleWidthTextField)
    {
        _clipCircleWidth = [self.circleWidthTextField.text floatValue];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
