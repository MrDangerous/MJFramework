//
//  FriendsCell.h
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/5.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^UpdateCellHeightBlock)(CGFloat cellHeigth, NSIndexPath *indexPath);

@interface FriendsCell : UITableViewCell

@property (copy, nonatomic) UpdateCellHeightBlock updateCellHeightBlock;

//设置数据源
- (void)setDataByDictonary:(NSDictionary *)dictionary indexPath:(NSIndexPath *)indexPath;

@end
