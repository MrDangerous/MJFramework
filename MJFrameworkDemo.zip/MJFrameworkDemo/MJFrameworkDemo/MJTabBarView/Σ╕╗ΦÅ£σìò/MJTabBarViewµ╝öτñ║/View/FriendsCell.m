//
//  likeCell.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/5.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "FriendsCell.h"

#import "ImageCollectionViewCell.h"
#import "LikesCollectionViewCell.h"

@interface FriendsCell()<UICollectionViewDataSource, UICollectionViewDelegate, MJCollectionViewDelegateFlowLayout>

//头像
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
//用户名
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
//发表内容
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
//图片CollectionView
@property (weak, nonatomic) IBOutlet UICollectionView *imagesCollectionView;
//点赞ImageView
@property (weak, nonatomic) IBOutlet UIImageView *likeImageView;
//点赞Button
@property (weak, nonatomic) IBOutlet UIButton *likeButton;
//点赞CollectionView
@property (weak, nonatomic) IBOutlet UICollectionView *likeCollectionView;

//约束，两个CollectionView 的高度。
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imagesCVHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *likeCVHeightConstraint;

@end

@implementation FriendsCell
{
    NSArray *imagesArray;
    NSMutableArray *likesArray;
    
    NSInteger horizontalMaxCount;  //水平方向最多放置x张图片
    NSInteger verticalityMaxCount; //垂直方向最多放置y张图片
    
    CGFloat imageXSpac;//图片水平间距
    
    ImageCollectionViewCell *imageCell;
    LikesCollectionViewCell *likeCell;
    
    NSIndexPath *tableView_IndexPath;
    CGFloat cellHeight;
    
    BOOL imageCellAlreadyDisplay;
    BOOL likeCellAlreadyDisplay;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    //
    [self initData];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

#pragma mark -

- (void)initData
{
    //============
    [self.imagesCollectionView registerNib:[UINib nibWithNibName:@"ImageCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"ImageCell"];
    self.imagesCollectionView.dataSource = self;
    self.imagesCollectionView.delegate = self;
    //
    MJCollectionViewFlowLayout *layout = [[MJCollectionViewFlowLayout alloc] init];
    imageXSpac = 5.0f;
    layout.minimumInteritemSpacing = imageXSpac;  //水平间距
    layout.minimumLineSpacing = imageXSpac;       //垂直间距
    layout.delegate = self;
    self.imagesCollectionView.collectionViewLayout = layout;
    
    //============
    [self.likeCollectionView registerNib:[UINib nibWithNibName:@"LikesCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"LikesCell"];
    self.likeCollectionView.dataSource = self;
    self.likeCollectionView.delegate = self;
    //
    MJCollectionViewFlowLayout *layout2 = [[MJCollectionViewFlowLayout alloc] init];
    layout2.minimumInteritemSpacing = 2.0f;  //水平间距
    layout2.minimumLineSpacing = 0.0f;       //垂直间距
    layout2.delegate = self;
    self.likeCollectionView.collectionViewLayout = layout2;
    
    //
    imageCell = [[[NSBundle mainBundle] loadNibNamed:@"ImageCollectionViewCell" owner:nil options:nil] firstObject];
    likeCell = [[[NSBundle mainBundle] loadNibNamed:@"LikesCollectionViewCell" owner:nil options:nil] firstObject];
    
    //
    horizontalMaxCount = 3;
    verticalityMaxCount = 3;
    
    //
    cellHeight = [self defaultCellHeight];
    likesArray = [NSMutableArray array];
    //
    imageCellAlreadyDisplay = NO;
    likeCellAlreadyDisplay = NO;
}

#pragma mark - private

- (CGFloat)defaultCellHeight
{
    return 135;
}

//设置数据源
- (void)setDataByDictonary:(NSDictionary *)dictionary indexPath:(NSIndexPath *)indexPath
{
    tableView_IndexPath = indexPath;
    
    imagesArray = dictionary[@"imagesArray"];
    likesArray = [NSMutableArray arrayWithArray:dictionary[@"likesArray"]];
    
    //姓名
    NSString *userName = dictionary[@"userName"];
    self.userNameLabel.text = userName;
    
    //头像
    self.headImageView.image = [UIImage imageNamed:@"head.jpeg"];
    
    //发表内容
    NSString *contentStr = dictionary[@"content"];
    self.contentLabel.text = contentStr;
    cellHeight += [self getContentStringHeight:contentStr];
    
    //判断是否点赞过
    BOOL isAlreadyLike = NO;
    for (NSString *name in likesArray) {
        if ([name isEqualToString:userName])
        {
            isAlreadyLike = YES;
            break;
        }
    }
    //UI默认未点赞
    if (isAlreadyLike)
    {
        self.likeImageView.image = [UIImage imageNamed:@"like"];
    }
}

#pragma mark - actions

//点击 点赞按钮
- (IBAction)clickLikeButtonAction:(id)sender
{
    //记录点击 点赞按钮前 数组是否存在点赞人数据
    BOOL beforeIsHaveLikes = (likesArray.count > 0) ? YES : NO;
    
    NSString *userName = self.userNameLabel.text;
    
    //判断是否点赞过
    BOOL isAlreadyLike = NO;
    for (NSString *name in likesArray) {
        if ([name isEqualToString:userName])
        {
            isAlreadyLike = YES;
            break;
        }
    }
    if (isAlreadyLike)
    {//之前点赞过
        self.likeImageView.image = [UIImage imageNamed:@"unlike"];
        [likesArray removeObject:userName];
    }
    else
    {
        self.likeImageView.image = [UIImage imageNamed:@"like"];
        [likesArray addObject:userName];
    }
    
    //
    if (likesArray.count == 0)
    {
        cellHeight -= self.likeCVHeightConstraint.constant;
        self.updateCellHeightBlock(cellHeight, tableView_IndexPath);
    }
    else
    {
        if (beforeIsHaveLikes)
        {//之前有数据，点赞操作后还有数据。
            cellHeight -= self.likeCVHeightConstraint.constant;
        }
        likeCellAlreadyDisplay = NO;
    }
    [self.likeCollectionView reloadData];
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (imagesArray.count == 0 && likesArray.count == 0)
    {
        self.updateCellHeightBlock(cellHeight, tableView_IndexPath);
    }
    if (collectionView == self.imagesCollectionView)
    {//图片
        return imagesArray.count;
    }
    else
    {//点赞
        return likesArray.count;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView == self.imagesCollectionView)
    {//图片
        ImageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ImageCell" forIndexPath:indexPath];
        self.imagesCVHeightConstraint.constant = self.imagesCollectionView.contentSize.height;
        imageCell = cell;
        
        if (imagesArray.count > indexPath.item)
        {
            NSInteger currentImageIndex = [MJUtilities getRowIndex:indexPath.item maxColNumber:horizontalMaxCount];
            if (currentImageIndex < verticalityMaxCount - 1)
            {//非最后一行，显示底部横线
                cell.horizontalLineView.hidden = NO;
            }
            else
            {
                cell.horizontalLineView.hidden = YES;//cell复用问题，要记得设置回来
            }
            if (indexPath.item % horizontalMaxCount != 0 && indexPath.item != 0)
            {//非最后一列，显示右边竖线
                cell.verticalLineView.hidden = NO;
            }
            else
            {
                cell.verticalLineView.hidden = YES;//cell复用问题，要记得设置回来
            }
            
            //显示图片
            cell.itemImageView.image = imagesArray[indexPath.item];
        }
        
        return cell;
    }
    else
    {//点赞
        LikesCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"LikesCell" forIndexPath:indexPath];
        self.likeCVHeightConstraint.constant = self.likeCollectionView.contentSize.height;
        likeCell = cell;
        
        if (likesArray.count > indexPath.item)
        {
            NSString *name = likesArray[indexPath.item];
            
            //非最后一个点赞姓名，同意末尾添加"、".
            if (indexPath.item != likesArray.count - 1)
            {
                name = [NSString stringWithFormat:@"%@、", name];
            }
            
            cell.likeUserNameLbl.text = name;
            
            if (indexPath.item == 0)
            {//第一个，显示点赞图标
                cell.likeImageView.hidden = NO;
                cell.likeImageViewWidthConstraint.constant = 16;
            }
            else
            {
                cell.likeImageView.hidden = YES;//cell复用问题，要记得设置回来
                cell.likeImageViewWidthConstraint.constant = 0;
            }
            
            if (indexPath.item == likesArray.count - 1)
            {//最后一个，显示"觉得很赞"
                cell.likeContentLbl.hidden = NO;
                cell.likeContentWidthConstraint.constant = 53.5;
                cell.likeContentLeadingConstraint.constant = 5;
            }
            else
            {
                cell.likeContentLbl.hidden = YES;//cell复用问题，要记得设置回来
                cell.likeContentWidthConstraint.constant = 0;
                cell.likeContentLeadingConstraint.constant = 0;
            }
        }
        
        return cell;
    }
}

#pragma mark - UICollectionViewDelegate

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView == self.imagesCollectionView)
    {//图片
        CGSize imageCellSize = [self getImageCellSize];
        return imageCellSize;
    }
    else
    {//点赞
        CGSize likeCellSize = [self getLikeCellSizeByIndexPath:indexPath];
        return likeCellSize;
    }
}

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.item == 0)
    {
        if ([cell isKindOfClass:[ImageCollectionViewCell class]])
        {
            if (self.imagesCVHeightConstraint.constant > 1)
            {
                imageCellAlreadyDisplay = YES;
                cellHeight += self.imagesCVHeightConstraint.constant;
            }
        }
        if ([cell isKindOfClass:[LikesCollectionViewCell class]])
        {
            if (self.likeCVHeightConstraint.constant > 1)
            {
                likeCellAlreadyDisplay = YES;
                cellHeight += self.likeCVHeightConstraint.constant;
                
            }
        }
        if ((imagesArray.count > 0 && imageCellAlreadyDisplay == NO) || (likesArray.count > 0 && likeCellAlreadyDisplay == NO))
        {}
        else
        {
            //动态计算cell高度完成。
            //NSLog(@"**************[%ld]-[%.0f]", tableView_IndexPath.row, cellHeight);
            self.updateCellHeightBlock(cellHeight, tableView_IndexPath);
        }
    }
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView == self.imagesCollectionView)
    {//图片
        NSString *msg = [NSString stringWithFormat:@"第%d张图片", (int)(indexPath.item + 1)];
        [MJUtilities showMJTipView:msg];
    }
    else
    {//点赞
        NSString *name = likesArray[indexPath.item];
        NSString *msg = [NSString stringWithFormat:@"%@", name];
        [MJUtilities showMJTipView:msg];
    }
}

#pragma mark -

//获取图片Cell Size
- (CGSize)getImageCellSize
{
    CGFloat width = (self.imagesCollectionView.frame.size.width - ((horizontalMaxCount + 1) * imageXSpac)) / horizontalMaxCount;
    CGFloat height = width;
    
    return CGSizeMake(width, height);
}

//获取点赞Cell Size
- (CGSize)getLikeCellSizeByIndexPath:(NSIndexPath *)indexPath
{
    if (likesArray.count > indexPath.item)
    {
        CGFloat width = 1;
        
        if (indexPath.item == 0)
        {//第一个，加上点赞图标宽度
            likeCell.likeImageViewWidthConstraint.constant = 16;
            width += likeCell.likeImageViewWidthConstraint.constant;
        }
        if (indexPath.item == likesArray.count - 1)
        {//最后一个，加上"觉得很赞"左间距和自身宽度
            width += likeCell.likeContentLeadingConstraint.constant + likeCell.likeContentWidthConstraint.constant;
        }
        
        NSString *userName = likesArray[indexPath.item];
        
        //非最后一个点赞姓名，统一末尾添加"、".
        if (indexPath.item != likesArray.count - 1)
        {
            userName = [NSString stringWithFormat:@"%@、", userName];
        }
        
        CGFloat nameWidth = [MJUtilities textWidth:userName fontSize:13];
        width += nameWidth;
        
        //
        CGSize likeCellSize = CGSizeMake(width, likeCell.frame.size.height);
        
        return likeCellSize;
    }
    else
    {
        return CGSizeZero;
    }
}

//计算发表内容的高度
- (CGFloat)getContentStringHeight:(NSString *)text
{
    CGFloat textHeight = [MJUtilities textRect:text font:self.contentLabel.font displaySize:CGSizeMake(self.contentLabel.frame.size.width, 0)].size.height;
    textHeight -= self.contentLabel.frame.size.height;
    return textHeight;
}

@end
