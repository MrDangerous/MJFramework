//
//  ImageCollectionViewCell.h
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/6.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *itemImageView;
@property (weak, nonatomic) IBOutlet UIView *horizontalLineView;
@property (weak, nonatomic) IBOutlet UIView *verticalLineView;

@end
