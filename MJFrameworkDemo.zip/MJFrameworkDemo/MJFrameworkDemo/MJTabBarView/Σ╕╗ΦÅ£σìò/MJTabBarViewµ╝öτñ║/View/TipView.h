//
//  TipView.h
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/5.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^TipViewBlock)(UIButton *btn, NSInteger btnIndex);

@interface TipView : UIView

@property (copy, nonatomic) TipViewBlock tipViewBlock;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
