//
//  LikesCollectionViewCell.m
//  TianRan
//
//  Created by iosapp on 16/6/15.
//  Copyright © 2016年 iOSApp. All rights reserved.
//

#import "LikesCollectionViewCell.h"

@interface LikesCollectionViewCell()

@end

@implementation LikesCollectionViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

@end
