//
//  TipView.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/5.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "TipView.h"

@interface TipView()

@property (weak, nonatomic) IBOutlet UIView *ContentView;

@end

@implementation TipView

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    //设置圆角
    [MJUtilities setCornerRadius:self.ContentView cornerRadiusValue:10];
}

- (IBAction)clickButtonAction:(UIButton *)sender {
    
    //tag:0 左边按钮(取消); tag:1 右边按钮(确定)
    if (self.tipViewBlock)
    {
        self.tipViewBlock(sender, sender.tag);
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
