//
//  LikesCollectionViewCell.h
//  TianRan
//
//  Created by iosapp on 16/6/15.
//  Copyright © 2016年 iOSApp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LikesCollectionViewCell : UICollectionViewCell

//赞图标
@property (weak, nonatomic) IBOutlet UIImageView *likeImageView;
//点赞人名
@property (weak, nonatomic) IBOutlet UILabel *likeUserNameLbl;
//觉得很赞
@property (weak, nonatomic) IBOutlet UILabel *likeContentLbl;

//约束
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *likeImageViewWidthConstraint;  //点赞icon宽
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *likeContentLeadingConstraint;  //觉得很赞居左距离
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *likeContentWidthConstraint;    //觉得很赞宽度

@end
