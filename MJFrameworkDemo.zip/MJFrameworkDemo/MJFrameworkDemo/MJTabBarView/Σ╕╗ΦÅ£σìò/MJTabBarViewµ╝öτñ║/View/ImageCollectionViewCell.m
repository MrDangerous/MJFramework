//
//  ImageCollectionViewCell.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/6.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "ImageCollectionViewCell.h"

@implementation ImageCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
