//
//  MJPopViewDemoVC.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/5.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "MJPopViewDemoVC.h"

#import "TipView.h"

@interface MJPopViewDemoVC ()

@property (weak, nonatomic) IBOutlet UILabel *testLabel;
@property (weak, nonatomic) IBOutlet UILabel *isCanClickHiddenLabel;

@end

@implementation MJPopViewDemoVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = setNavigationBarTitleView(@"UIView+PopView用法演示");
    
    //
    self.isCanClickHiddenLabel.textColor = MainDefaultColor;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - actions

//是否可点击隐藏弹出 开关
- (IBAction)changeIsCanClickHiddenSwitch:(id)sender
{
    UISwitch *switchView = (UISwitch *)sender;
    BOOL isOn = [switchView isOn];
    if (isOn)
    {
        self.isCanClickHiddenLabel.text = @"YES";
        self.isCanClickHiddenLabel.textColor = MainDefaultColor;
    }
    else
    {
        self.isCanClickHiddenLabel.text = @"NO";
        self.isCanClickHiddenLabel.textColor = [UIColor redColor];
    }
}

//居中弹出
- (IBAction)displayCenter:(id)sender
{
    BOOL isCanClick = [self.isCanClickHiddenLabel.text boolValue];
    
    //
    TipView *tipView = [[[NSBundle mainBundle] loadNibNamed:@"TipView" owner:nil options:nil] firstObject];
    
    //tipView.titleLabel.text = @"居中弹出";
    
    UIView *popView = [self.navigationController.view popViewToScreenCenter:tipView backgroundViewAlpha:0.6 isCanClickBackGroundView:isCanClick];
    
    [self.navigationController.view addSubview:popView];
    
    tipView.tipViewBlock = ^(UIButton *btn, NSInteger btnIndex){
        //
        NSString *msg = [NSString stringWithFormat:@"您点击了弹窗 \"%@\"按钮", btn.titleLabel.text];
        [MJUtilities showMJTipView:msg];
        [self.navigationController.view removePopView:popView];
    };
    
}

//test Label 左下角弹出
- (IBAction)displayLeftBottom:(id)sender
{
    CGPoint point = self.testLabel.bottomLeft;
    point.y += 5;
    BOOL isCanClick = [self.isCanClickHiddenLabel.text boolValue];
    
    //
    TipView *tipView = [[[NSBundle mainBundle] loadNibNamed:@"TipView" owner:nil options:nil] firstObject];
    
    //tipView.titleLabel.text = @"test Label 左下角弹出";
    
    UIView *popView = [self.navigationController.view popViewToScreenLeftTop:tipView backgroundViewAlpha:0.6 isCanClickBackGroundView:isCanClick leftTopPoint:point];
    
    [self.navigationController.view addSubview:popView];
    
    tipView.tipViewBlock = ^(UIButton *btn, NSInteger btnIndex){
        //
        NSString *msg = [NSString stringWithFormat:@"您点击了弹窗 \"%@\"按钮", btn.titleLabel.text];
        [MJUtilities showMJTipView:msg];
        [self.navigationController.view removePopView:popView];
    };
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
