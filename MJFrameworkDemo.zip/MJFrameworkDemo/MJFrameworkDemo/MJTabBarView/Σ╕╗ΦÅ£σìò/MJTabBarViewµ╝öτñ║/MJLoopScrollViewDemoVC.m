//
//  MJLoopScrollViewDemoVC.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/4.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "MJLoopScrollViewDemoVC.h"

@interface MJLoopScrollViewDemoVC ()<UITextFieldDelegate, UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *loopSrollBGView;
//
@property (weak, nonatomic) IBOutlet UITextField *pageControlBottomTextField;
@property (weak, nonatomic) IBOutlet UITextField *imageDisplayTimeTextField;

@end

@implementation MJLoopScrollViewDemoVC
{
    UITextField *currentTextField;//记录当前操作的TextField
    CGFloat scrollHeight;//滑动距离
    
    MJLoopScrollView *mjLoopScrollView;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = setNavigationBarTitleView(@"MJLoopScrollView用法演示");
    
    //监听横竖屏切换
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientChange) name:UIDeviceOrientationDidChangeNotification object:nil];
    
    //添加点击屏幕缩回键盘
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backKeyBoard)];
    [self.view addGestureRecognizer:tap];
    
    //键盘弹出，缩回
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];

}

- (void)keyboardWillShow:(NSNotification *)notify
{
    CGFloat yOffset = kNavigationHeight + currentTextField.bottom - scrollHeight + 30;
    [MJUtilities keyboardWillShow:notify superView:self.view yOffset:yOffset];
}

- (void)keyboardWillHide:(NSNotification *)notify
{
    [MJUtilities keyboardWillHide:notify superView:self.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initLoopScrollView
{
    mjLoopScrollView = [[MJLoopScrollView alloc] init];
    mjLoopScrollView.frame = self.loopSrollBGView.bounds;
    [self.loopSrollBGView addSubview:mjLoopScrollView];
    
    //图片数组
    NSMutableArray *imageM = [NSMutableArray array];
    
    [imageM addObject:@"http://sports.espn.go.com/photo/2008/0423/nba_ap_kbryant1_412.jpg"];
    [imageM addObject:@"http://upload.taihainet.com/2016/1111/1478797486684.jpeg"];
    [imageM addObject:@"http://d.hiphotos.baidu.com/zhidao/pic/item/cb8065380cd7912314b44633ad345982b2b78025.jpg"];
    [imageM addObject:@"http://d.hiphotos.baidu.com/zhidao/pic/item/4e4a20a4462309f76307dba4740e0cf3d7cad618.jpg"];
    [imageM addObject:@"http://www.cnidea.net/zhibo/u/20160414/16104807373250436817.jpg"];
    
    [mjLoopScrollView startAutoRunningImages:imageM clickAction:^(UIImageView *imageView, int index) {
        NSString *msg = [NSString stringWithFormat:@"您点击的是:图片%d", index];
        [MJUtilities showMJTipView:msg];
    }];
}

#pragma mark - actions

//启动轮播图
- (IBAction)start:(id)sender
{
    if (!mjLoopScrollView)
    {
        [self initLoopScrollView];
    }
    else
    {
        [mjLoopScrollView startTimer];
    }
}

//暂停轮播图
- (IBAction)stop:(id)sender
{
    [mjLoopScrollView pauseTimer];
}

//pageControl 居左
- (IBAction)showLeft:(id)sender
{
    [mjLoopScrollView setPageControlAlignment:MJBottomLeft];
}

//pageControl 居中
- (IBAction)showCenter:(id)sender
{
    [mjLoopScrollView setPageControlAlignment:MJBottomCenter];
}

//pageControl 居右
- (IBAction)showRight:(id)sender
{
    [mjLoopScrollView setPageControlAlignment:MJBottomRight];
}

//默认白色
- (IBAction)normalWhiteColor:(id)sender
{
    [mjLoopScrollView setDefaultColor:[UIColor whiteColor]];
}

//默认灰色
- (IBAction)normalGrayColor:(id)sender
{
    [mjLoopScrollView setDefaultColor:[UIColor grayColor]];
}

//选中绿色
- (IBAction)selectGreenColor:(id)sender
{
    [mjLoopScrollView setSelectedColor:[UIColor greenColor]];
}

//选中黄色
- (IBAction)selectYellowColor:(id)sender
{
    [mjLoopScrollView setSelectedColor:[UIColor yellowColor]];
}

//是否显示pageControl
- (IBAction)clickIsShowPageControl:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    BOOL isButtonOn = [switchButton isOn];
    if (isButtonOn)
    {
        [mjLoopScrollView setShowPageControl:YES];
    }
    else
    {
        [mjLoopScrollView setShowPageControl:NO];
    }
}

//是否自动播放轮播图
- (IBAction)clickIsAutoPlay:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    BOOL isButtonOn = [switchButton isOn];
    if (isButtonOn)
    {
        [mjLoopScrollView setAutoScroll:YES];
    }
    else
    {
        [mjLoopScrollView setAutoScroll:NO];
    }
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentTextField = textField;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == self.imageDisplayTimeTextField)
    {
        CGFloat time = [textField.text floatValue];
        [mjLoopScrollView setTimeInterval:time];
    }
    else if (textField == self.pageControlBottomTextField)
    {
        CGFloat bottom = [textField.text floatValue];
        [mjLoopScrollView setPageControlSpacBottom:bottom];
    }
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    scrollHeight = scrollView.contentOffset.y;
    if (scrollHeight < 0)//只记录往下滑动的数值
    {
        scrollHeight = 0;
    }
}

#pragma mark -

- (void)backKeyBoard
{
    [currentTextField resignFirstResponder];
}

#pragma mark -

//屏幕旋转
- (void)orientChange
{
    CGRect rect = self.loopSrollBGView.bounds;
    [mjLoopScrollView orientChangeUpdateFrame:rect];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
