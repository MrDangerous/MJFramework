//
//  MJCollectionViewFlowLayoutDemoVC.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/5.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "MJCollectionViewFlowLayoutDemoVC.h"

#import "FriendsCell.h"

@interface MJCollectionViewFlowLayoutDemoVC ()<UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *myTableView;

@end

@implementation MJCollectionViewFlowLayoutDemoVC
{
    NSMutableArray *dataArray;
    NSMutableDictionary *cellHeightDic;
    FriendsCell *friendsCell;
    
    BOOL isSetData;//是否已设置数据
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = setNavigationBarTitleView(@"朋友圈");
    
    //
    [self setData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -

- (void)setData
{
    _myTableView.tableFooterView = [[UIView alloc] init];
    _myTableView.showsVerticalScrollIndicator = NO;
    _myTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_myTableView registerNib:[UINib nibWithNibName:@"FriendsCell" bundle:nil] forCellReuseIdentifier:@"FriendsCell"];
    
    friendsCell = [[[NSBundle mainBundle] loadNibNamed:@"FriendsCell" owner:nil options:nil] firstObject];
    
    cellHeightDic = [NSMutableDictionary dictionary];
    
    //设置模拟数据
    dataArray = [NSMutableArray array];
    NSMutableDictionary *dictM = [NSMutableDictionary dictionary];
    //
    dictM[@"userName"] = @"科比·布莱恩特";
    dictM[@"content"] = @"李世石与AlphaGo人机大战第四局，就是因为李世石走出了一步在当时AlphaGo计算之外的“神之一手”，令AlphaGo在当时比赛的用时策略下“计算力”不足，出现程序BUG，继而崩盘。即使是计算能力强大的人工智能，在近乎无限的围棋盘上，也肯定会有“漏算”的情况。";
    dictM[@"imagesArray"] = @[[UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],];
    dictM[@"likesArray"] = @[@"魔术师",@"詹姆斯",@"奥尼尔",@"奥拉朱旺",@"麦迪",@"加内特",@"库里"];
    [dataArray addObject:dictM];
    //
    dictM = [NSMutableDictionary dictionary];
    dictM[@"userName"] = @"郭明健";
    dictM[@"content"] = @"您果然深思熟虑！";
    dictM[@"imagesArray"] = @[[UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],
                              [UIImage imageNamed:@"backgroundImage"],];
    dictM[@"likesArray"] = @[@"陈意涵",];
    [dataArray addObject:dictM];
    
    //
    isSetData = NO;
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FriendsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FriendsCell" forIndexPath:indexPath];
    
    if (dataArray.count > indexPath.row)
    {//避免数组越界
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        friendsCell = cell;
        
        if (isSetData == NO)
        {
            [cell setDataByDictonary:dataArray[indexPath.row] indexPath:indexPath];
            if (indexPath.row == dataArray.count - 1)
            {
                isSetData = YES;
            }
        }
        
        //刷新UI
        cell.updateCellHeightBlock = ^(CGFloat cellHeight, NSIndexPath *_indexPath){
            NSString *key = [NSString stringWithFormat:@"%d", (int)_indexPath.row];
            cellHeightDic[key] = [NSString stringWithFormat:@"%.0f", cellHeight];
            [self.myTableView reloadData];//isSetData
            //[self tableView:tableView heightForRowAtIndexPath:_indexPath];
        };
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *key = [NSString stringWithFormat:@"%d", (int)indexPath.row];
    CGFloat height = [cellHeightDic[key] floatValue];
    
    if (!height)
    {
        height = [friendsCell defaultCellHeight];
    }
    //NSLog(@"[%ld]-[%.0f]", indexPath.row, height);
    return height;
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
