//
//  MJUtilitiesDemoVC.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/3.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "MJUtilitiesDemoVC.h"

@interface MJUtilitiesDemoVC ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *phoneTextField;
@property (weak, nonatomic) IBOutlet UITextField *sizeTextField;
@property (weak, nonatomic) IBOutlet UITextField *changeStrTextField;
//
@property (weak, nonatomic) IBOutlet UITextField *timeTextField;
@property (weak, nonatomic) IBOutlet UITextField *pisitionTextField;
//
@property (weak, nonatomic) IBOutlet UIButton *countDownButton;
@property (weak, nonatomic) IBOutlet UILabel *runLabel;
@property (weak, nonatomic) IBOutlet UIButton *runButton;
@property (weak, nonatomic) IBOutlet UIView *runView;

@end

@implementation MJUtilitiesDemoVC
{
    UITextField *currentTextField;//记录当前操作的TextField
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = setNavigationBarTitleView(@"MJUtilities用法演示");
    
    //添加点击屏幕缩回键盘
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backKeyBoard)];
    [self.view addGestureRecognizer:tap];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - actions

//改变Placeholder字体大小
- (IBAction)changePlaceholderSize:(id)sender
{
    CGFloat fontSize = [self.sizeTextField.text floatValue];
    
    [MJUtilities setPlaceholderColor:nil fontSize:fontSize textField:self.phoneTextField];
}

//改变Placeholder颜色
- (IBAction)changePlaceholderColor:(id)sender
{
    CGFloat fontSize = [self.sizeTextField.text floatValue];
    NSString *changeStr = self.changeStrTextField.text;
    
    [MJUtilities setPlaceholderColor:[UIColor redColor] string:changeStr fontSize:fontSize textField:self.phoneTextField];
}

//显示自定义提示框
- (IBAction)showMJMsgTipView:(id)sender
{
    NSString *tipString = @"科比是NBA最好的得分手之一，突破、投篮、罚球、三分球他都驾轻就熟，几乎没有进攻盲区，单场比赛81分的个人纪录就有力地证明了这一点。";
    //显示时间
    CGFloat displayTime = [self.timeTextField.text floatValue];
    //显示位置
    MJ_Alignment alignment;
    NSString *pisitionStr = self.pisitionTextField.text;
    if ([pisitionStr isEqualToString:@"1"])
    {
        alignment = MJ_Top;
    }
    else if ([pisitionStr isEqualToString:@"2"])
    {
        alignment = MJ_Bottom;
    }
    else
    {
        alignment = MJ_Center;
    }
    
    [MJUtilities showMJTipView:tipString displayTime:displayTime alignment:alignment];
}

//开始倒计时
- (IBAction)startCountDown:(id)sender
{
    [MJUtilities startCountdownAtButton:self.countDownButton
                              totalTime:60 textColor:self.countDownButton.titleLabel.textColor
                               textFont:self.countDownButton.titleLabel.font
                          timeAfterText:@" 秒后重新发送"];
}

//开启跑马灯动画
- (IBAction)startTextRunning:(id)sender
{
    NSString *tipString = @"科比是NBA最好的得分手之一，突破、投篮、罚球、三分球他都驾轻就熟，几乎没有进攻盲区，单场比赛81分的个人纪录就有力地证明了这一点。";
    UIColor *color = MainDefaultColor;
    
    [MJUtilities textRunningAtSuperView:self.runLabel text:tipString textColor:color isCanClickText:YES];
    [MJUtilities textRunningAtSuperView:self.runButton text:tipString textColor:color isCanClickText:YES];
    [MJUtilities textRunningAtSuperView:self.runView text:tipString textColor:color isCanClickText:YES];
    
    //
    //[MJUtilities textRunningAtSuperView:self.runLabel text:tipString textColor:color isCanClickText:YES runOneScreenWidthDuration:7];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentTextField = textField;
}

#pragma mark -

- (void)backKeyBoard
{
    [currentTextField resignFirstResponder];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
