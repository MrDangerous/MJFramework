//
//  MJActivityViewDemoVC.m
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2017/1/3.
//  Copyright © 2017年 MJ Guo. All rights reserved.
//

#import "MJActivityViewDemoVC.h"

@interface MJActivityViewDemoVC ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *widthTextField;
@property (weak, nonatomic) IBOutlet UITextField *dotNumberTextField;

@end

@implementation MJActivityViewDemoVC
{
    UITextField *currentTextField;//记录当前操作的TextField
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = setNavigationBarTitleView(@"MJActivityView用法演示");
    
    //添加点击屏幕缩回键盘
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backKeyBoard)];
    [self.view addGestureRecognizer:tap];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] hiddenMJTabBar];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[MJTabBarView getMJTabBar:self.tabBarController] showMJTabBar];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - actions

//显示菊花器
- (IBAction)showMJActivityView:(id)sender
{
    UIColor *color = kRandomColor;
    CGFloat width = [self.widthTextField.text floatValue];
    NSInteger dotNumber = [self.dotNumberTextField.text integerValue];
    
    [MJActivityView setMJActivityColor:color];
    [MJActivityView setMJActivityWidth:width];
    [MJActivityView setMJActivityDotNumber:dotNumber];
    
    [MJActivityView showMJActivity];
}

//隐藏菊花器
- (IBAction)hiddenMJActivityView:(id)sender
{
    [MJActivityView hideMJActivity];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    currentTextField = textField;
}

#pragma mark -

- (void)backKeyBoard
{
    [currentTextField resignFirstResponder];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
