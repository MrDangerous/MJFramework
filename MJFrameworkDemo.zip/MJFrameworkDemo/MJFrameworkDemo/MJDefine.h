//
//  MJDefine.h
//  MJFrameworkDemo
//
//  Created by GuoMingJian on 2016/12/30.
//  Copyright © 2016年 MJ Guo. All rights reserved.
//

#ifndef MJDefine_h
#define MJDefine_h

#import <MJFramework/MJFramework.h>

#define setNavigationBarTitleView(text) [MJUtilities labelWithText:text fontSize:19 textColor:[UIColor whiteColor] numberOfLines:1 textAlignment:NSTextAlignmentCenter backgroundColor:nil frame:CGRectMake(0, 0, 150, 21)];

#define MainDefaultColor kRGBColor(40, 167, 66)

#endif /* MJDefine_h */
